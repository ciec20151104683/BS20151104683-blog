package blog.com.cn.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import blog.com.cn.dao.JdbcUtils;

/**
 * Servlet implementation class Index
 */
@WebServlet("/index")
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public IndexServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			JdbcUtils jdbcUtils = new JdbcUtils();
			jdbcUtils.getConnection();
			String pageNo = request.getParameter("pageNo");
			if (pageNo == null || pageNo.isEmpty()) {
				pageNo = "1";
			}
			int pageSize = 10;
			int startRow = setStartRow(Integer.parseInt(pageNo), pageSize);
			String sql_count = "select count(id) as js from article ";
			Map m = jdbcUtils.findSimpleResult(sql_count, null);
			long count = (Long) m.get("js");
			int pages = setPages(count, pageSize);

			List<Object> param = new ArrayList<Object>();
			param.add(startRow);
			param.add(pageSize);

			String sql = "select * from article  order by cts  desc"
					+ " limit ?,? ";

			List li = jdbcUtils.findModeResult(sql, param);

			request.setAttribute("articleli", li);
			request.setAttribute("pageNo", Integer.parseInt(pageNo));
			request.setAttribute("pages", pages);
			request.setAttribute("count", count);
			request.getRequestDispatcher("/jsp/index.jsp").forward(request,
					response);

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	private int setStartRow(Integer pageNo, Integer pageSize) {
		return (pageNo - 1) * pageSize;
	}

	private int setPages(Long count1, Integer pageSize1) {
		int p = new Integer(count1 + "") % pageSize1;
		if (p == 0)
			return new Integer(count1 + "") / pageSize1;
		else
			return new Integer(count1 + "") / pageSize1 + 1;
	}

}
