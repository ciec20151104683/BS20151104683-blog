package blog.com.cn.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import blog.com.cn.dao.JdbcUtils;
import blog.com.cn.tool.DateUtil;

/**
 * Servlet implementation class Index
 */
@WebServlet("/reg")
public class RegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		try {
			String uname = request.getParameter("uname");
			String upass = request.getParameter("upass");

			JdbcUtils jdbcUtils = new JdbcUtils();
			jdbcUtils.getConnection();

			String sql3 = "select * from userInfo where uname=?";
			List<Object> param3 = new ArrayList<Object>();
			param3.add(uname);
			Map users3 = jdbcUtils.findSimpleResult(sql3, param3);
			if (users3 != null&&users3.size()>0) {
				request.setAttribute("msg", "用戶名已存在");
				request.getRequestDispatcher("/toreg").forward(request,
						response);
				return;
			}

			List<Object> param = new ArrayList<Object>();
			param.add(uname);
			param.add(upass);

			String sql = "insert into userinfo (uname,upass) values (?,?)";

			int id = jdbcUtils.updateByPreparedStatement(sql, param);
			Map users = new HashMap();
			users.put("id", id);
			users.put("uname", uname);
			users.put("upass", upass);

			request.getSession().setAttribute("userInfo", users);

			request.setAttribute("msg", "提交成功");
			request.getRequestDispatcher("/index").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
