package blog.com.cn.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import blog.com.cn.dao.JdbcUtils;
import blog.com.cn.tool.DateUtil;

/**
 * Servlet implementation class Index
 */
@WebServlet("/login")
public class LoginServlst extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlst() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		JdbcUtils jdbcUtils = new JdbcUtils();  
		jdbcUtils.getConnection();
		String uname=request.getParameter("uname");
		String upass=request.getParameter("upass");
		
		List<Object> param=new ArrayList<Object>();
		param.add(uname);
		param.add(upass);
		
		String sql="select * from userInfo where uname=? and upass=?";
		
		Map<String, Object> map=null;
		try {
			map = jdbcUtils.findSimpleResult(sql,param);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		 
		if(map!=null&&!map.isEmpty()){
			request.getSession().setAttribute("userInfo", map);
			System.out.println(request.getSession().getAttribute("userInfo")+"---session"); 
			request.getRequestDispatcher("index").forward(request, response);
		}else {
			request.setAttribute("msg","用户名或者密码错误！");
			request.getRequestDispatcher("tologin").forward(request, response);
		}

	}

}
