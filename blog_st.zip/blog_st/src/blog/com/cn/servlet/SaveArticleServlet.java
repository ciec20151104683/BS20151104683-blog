package blog.com.cn.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import blog.com.cn.dao.JdbcUtils;
import blog.com.cn.tool.DateUtil;

/**
 * Servlet implementation class Index
 */
@WebServlet("/saveArticle")
public class SaveArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveArticleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		JdbcUtils jdbcUtils = new JdbcUtils();  
		jdbcUtils.getConnection();
		
		String title=request.getParameter("title"); 
		String context=request.getParameter("context");
		String cts=DateUtil.DateTimeToString(new Date());
		String descp=context;
		if(context!=null&&!context.isEmpty()&&context.trim().length()>200)
			descp=context.substring(0, 200)+"...";
		Map users=(Map) request.getSession().getAttribute("userInfo");
		if(users==null||users.isEmpty()){
			request.getRequestDispatcher("index").forward(request, response);
			return;
		}
		int uid=(int) users.get("id");
		
		List<Object> param=new ArrayList<Object>();
		param.add(title);
		param.add(context);
		param.add(cts);
		param.add(descp);
		param.add(uid);
		
		String sql="insert into article (title, context,cts,descp,uid) values (?, ?,?,?,?)";
		
		
		int r=-1;
		try {
			r = jdbcUtils.updateByPreparedStatement(sql, param);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		 
		if(r>0) {
			request.setAttribute("id", r);
			request.setAttribute("type", "addblogsucc");
			request.getRequestDispatcher("/jsp/succ.jsp").forward(request, response);
		}else{
			request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
		}
		 

	}

}
